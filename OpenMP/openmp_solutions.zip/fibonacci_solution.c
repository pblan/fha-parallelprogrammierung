/*
 *  OpenMP lecture exercises
 *  Copyright (C) 2011 by Christian Terboven <terboven@rz.rwth-aachen.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int fib_ser(int);


int fib(int n)
{
  if (n < 30) 
	  return fib_ser(n);

  int x, y;

#pragma omp task shared(x)
  x = fib(n - 1);

#pragma omp task shared(y)
  y = fib(n - 2);

#pragma omp taskwait
  return x+y;

}

int fib_ser(int n)
{

  if (n < 2) 
  {
	  return n;
  }
  
  int x, y;
  
  x = fib_ser(n - 1);

  y = fib_ser(n - 2);

  return x+y;
}


int main()
{
  int n,fibonacci;
  double starttime;
  printf("Please insert n, to calculate fib(n): \n");
  scanf("%d",&n);


  starttime=omp_get_wtime();

#pragma omp parallel
{
  #pragma omp single
  fibonacci=fib(n);
}

  printf("fib(%d)=%d \n",n,fibonacci);
  printf("calculation took %lf sec\n",omp_get_wtime()-starttime);
  return 0;
}
